1. Altere o c�digo do ficheiro db_model.sql para apontar para a sua BD e crie as tabelas respectivas. Crie um projecto no visual studio para uma aplica��o de consola c# de nome EF1. 
-Instale o pacote da Entity Framework (�Install-Package EntityFramework�) 
-Adicione um novo item ao projecto (�ADO.NET Entity Data Model� com abordagem DB First) de nome EF1 e aponte para a sua BD.
	a) Crie o c�digo c# necess�rio para inserir dados em todas as tabelas.
	b) Crie o c�digo c# necess�rio para listar o conte�do de todos os alunos e respectivos cursos associados.

	note: To change the connection string you can use this template to replace the existing one:
	data source=10.62.73.95;initial catalog=TL51N_1;user id=TL51N_1;password=TL51N_1