use SI2_AP3;
delete from Hobbies
delete from Alunos

insert into alunos values(1111,'rui')
insert into alunos values(2222,'ana')

insert into Hobbies values(1111,'i1')
insert into Hobbies values(1111,'i2')
insert into Hobbies values(2222,'i1')


